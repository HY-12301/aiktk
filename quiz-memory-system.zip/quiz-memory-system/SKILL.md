---
name: quiz-memory-system
description: 构建带间隔重复记忆算法的刷题学习系统。提供分层抽样出题、SM-2 算法实现、知识点薄弱追踪、巩固制错题管理、手动暗夜模式切换。支持离线预处理题库归纳知识点。适用于法考、考研、语言学习等任何需要长期记忆强化的刷题场景。
agent_created: true
---

# 带记忆系统的刷题应用构建

构建任何带间隔重复（Spaced Repetition）记忆算法的学习/刷题应用时，使用本技能中定义的模式和算法。

## 何时使用

- 用户要做一个刷题系统（法考、考研、语言、证书等）
- 用户需要错题管理功能，不想简单"做对一次就消失"
- 用户提到"间隔重复"、"SM-2"、"记忆曲线"、"艾宾浩斯"
- 用户需要暗夜模式适配（特别是夸克浏览器兼容）
- 用户需要知识点薄弱分析或智能出题排序

## 核心架构

### 1. 分层抽样出题算法

替代简单的优先级排序，使用 6 桶分层抽样：

```
桶                    占比上限      排序规则
──────────────────────────────────────────
到期复习 (overdue)   15%           逾期天数 DESC
重新学习 (relearning) 不限量         逾期天数 DESC
学习阶段 (learning)   不限量         学习步骤 DESC
薄弱知识点 (weak)     25%           薄弱度 DESC
未见过 (unseen)       35%           随机打散
已掌握 (seen)         10%           随机打散
```

桶之间交错排列（Round-Robin 交错），避免同类型连续出现。

### 2. 知识点弱点追踪 (KW)

每道题答完后更新知识点权重：

```javascript
// 数据结构
localStorage.kw = {
  "刑法.抢劫罪": { w: 3, t: 12, ts: "2026-07-09" },
  "民法.善意取得": { w: 0, t: 8, ts: "2026-07-05" },
}

// 薄弱度公式
weakness = (错误次数/总次数) × (1 + 距上次练习天数/14)
```

分数越高 → 越薄弱 → 越优先推送。

### 3. 混合权重排序 (rWt)

```javascript
score = 知识点薄弱度 × 0.6 + 记忆逾期天数 × 0.015
```

排序后做同 topic 隔离：相邻题目强制不重复知识点。

### 4. 离线知识点归纳

用 Python 预处理题库，给每道题加 `topic` 字段：

```python
def extract_topic(q):
    r = q['questionResolution']
    # Layer 1: 本题(考查|考点|涉及|体现)XXX
    m = re.search(r'本题(?:考查|考点|涉及|体现)(.+?)[。，、\n]', r)
    if m and not is_junk(m.group(1)):
        return f"{law}.{m.group(1)[:16]}"
    # Layer 2-4: fallback patterns...
    return f"{law}.other"
```

关键：设置垃圾过滤黑名单，排除"正确答案为D选项""中"等非知识点文本。

前端直接读 `q.topic`，不再运行时正则匹配。

### 5. SM-2 记忆算法

参考 `references/sm2.js` 中的完整实现。核心：

- **三阶段**：new → learning(30min/2h/1d) → exponential(interval × EF) → 答错时 relearning
- **EF 更新**：q 大于等于 3 时 EF += 0.1; q 小于 3 时 EF -= 0.2，下限 1.3
- **延迟奖励**：逾期答对时 bonus = 逾期天数 frac 难度分隔值
- **巩固制移出**：四条件 (exponential + EF 大于等于 2.3 + 连对 2 次 + 跨 3 天)

### 6. 暗夜模式

- 不用 `prefers-color-scheme`（夸克等国产浏览器不兼容）
- 手动 `.dark` class 切换，localStorage 持久化
- 按钮放左上角 absolute 定位，SVG 太阳/月亮图标

### 7. 数据存储与同步

- localStorage key: `s`，结构 `{w, t, k, s, h, done, mem, kw}`
- 云端同步时合并 `done`/`mem`/`kw` 字段
- 云端同步合并 `kw` 时使用 mergeArr 策略

## 编码模式

- 压缩 CSS（单字母类名、紧凑选择器）保持单文件可维护
- 移动端优先媒体查询 `@media(max-width:768px)`
- 内联关键样式 + 外联补充规则
- 避免 emoji 用于 UI 标签（渲染不一致）
- 所有交互状态存 localStorage
