// Stratified Sampling + SM-2 + Knowledge Weight — Reference Implementation
// Copy and adapt these functions into your quiz app.

// ================================================================
// KNOWLEDGE WEIGHT TRACKING
// ================================================================

// Pre-compute topics offline with Python, then use directly:
function topicKey(q){ return q.topic || (q.lawName + '.other'); }

function upKW(q, ok){
  var d = GS(), tk = topicKey(q), rec = d.kw[tk] || { w: 0, t: 0, ts: '' };
  rec.t = (rec.t || 0) + 1;
  if (!ok) rec.w = (rec.w || 0) + 1;
  rec.ts = new Date().toISOString();
  d.kw[tk] = rec; SS(d);
  debounceSync();
}

function kwWeakness(tk){
  var d = GS(), rec = d.kw[tk];
  if (!rec || !rec.t) return 0;
  var wr = rec.w / rec.t;
  var days = rec.ts ? Math.floor((Date.now() - new Date(rec.ts).getTime()) / 86400000) : 0;
  return wr * (1 + days / 14);
}

// ================================================================
// STRATIFIED SAMPLING — 6-bucket doS()
// ================================================================

function doS(s, z, m){
  // ... filter pool ...

  var now = new Date(), nowT = now.getTime();

  // 6 buckets
  var bucket = { overdue: [], relearn: [], learning: [], weak: [], unseen: [], seen: [] };

  pool.forEach(function(q){
    var mem = geM(q.id);

    // Spot-check
    if (mem && mem.spotCheck && new Date(mem.spotCheck).getTime() <= nowT) {
      bucket.overdue.unshift(q);
      // dedupe push back to error book
      return;
    }

    // Memory urgency
    if (mem) {
      var due = mem.nextReview ? new Date(mem.nextReview).getTime() : 0;
      if (mem.phase === 'relearning' && due <= nowT) bucket.relearn.push(q);
      else if (mem.phase === 'exponential' && due <= nowT) bucket.overdue.push(q);
      else if (mem.phase === 'learning' && due <= nowT) bucket.learning.push(q);
    }

    // Knowledge weakness
    var ws = kwWeakness(topicKey(q));
    if (ws > 0.25) bucket.weak.push(q);

    // Unseen
    if (!mem) bucket.unseen.push(q);

    // Seen but not due
    if (mem && !isDue(q, nowT)) bucket.seen.push(q);
  });

  // Sort buckets
  bucket.overdue.sort(byOverdue);
  bucket.relearn.sort(byOverdue);
  bucket.learning.sort(function(a, b){ return (geM(b.id).learningStepIdx || 0) - (geM(a.id).learningStepIdx || 0); });
  bucket.weak.sort(function(a, b){ return kwWeakness(topicKey(b)) - kwWeakness(topicKey(a)); });
  shuffle(bucket.unseen);
  shuffle(bucket.seen);

  // Dynamic allocation ratios
  var total = pool.length;
  var limO = Math.min(bucket.overdue.length, Math.ceil(total * 0.15));
  var limR = bucket.relearn.length;
  var limL = bucket.learning.length;
  var limW = Math.min(bucket.weak.length, Math.ceil(total * 0.25));
  var limU = Math.min(bucket.unseen.length, Math.ceil(total * 0.35));
  var limS = Math.min(bucket.seen.length, Math.ceil(total * 0.10));

  var o = bucket.overdue.slice(0, limO), r = bucket.relearn.slice(0, limR), l = bucket.learning.slice(0, limL);
  var w = bucket.weak.slice(0, limW), u = bucket.unseen.slice(0, limU), se = bucket.seen.slice(0, limS);

  // Interleave
  S = interleave([o, r, l, w, u, se]);

  // Append overflow
  S = S.concat(overflow);
  // ... start quiz ...
}

function interleave(arrays){
  var srcs = arrays.filter(function(a){ return a.length > 0; });
  var maxLen = Math.max.apply(null, srcs.map(function(a){ return a.length; }));
  var result = [], pos = srcs.map(function(){ return 0; });
  for (var round = 0; round < maxLen; round++) {
    var start = round % srcs.length;
    for (var si = 0; si < srcs.length; si++) {
      var idx = (start + si) % srcs.length;
      if (pos[idx] < srcs[idx].length) result.push(srcs[idx][pos[idx]++]);
    }
  }
  return result;
}

// ================================================================
// HYBRID WEIGHTING rWt() — Knowledge + Memory
// ================================================================

function rWt(){
  if (I >= S.length - 1) return;
  var rm = S.slice(I + 1), remBefore = S.slice(0, I + 1);

  rm.sort(function(a, b){
    var ta = topicKey(a), tb = topicKey(b);
    var ka = kwWeakness(ta), kb = kwWeakness(tb);
    var ma = geM(a.id), mb = geM(b.id);
    var ua = ma && ma.nextReview ? Math.max(0, (Date.now() - new Date(ma.nextReview).getTime()) / 86400000) : 0;
    var ub = mb && mb.nextReview ? Math.max(0, (Date.now() - new Date(mb.nextReview).getTime()) / 86400000) : 0;
    return (kb * 0.6 + ub * 0.015) - (ka * 0.6 + ua * 0.015);
  });

  // Topic isolation: don't repeat same topic consecutively
  S = remBefore.concat(isolateTopics(rm));
}

function isolateTopics(arr){
  var result = [], pending = arr.slice(), lastTopic = '';
  while (pending.length) {
    var best = -1;
    for (var i = 0; i < pending.length; i++) {
      if (topicKey(pending[i]) !== lastTopic) { best = i; break; }
    }
    if (best === -1) best = 0;
    result.push(pending[best]);
    lastTopic = topicKey(pending[best]);
    pending.splice(best, 1);
  }
  return result;
}

// ================================================================
// SM-2 MEMORY STATE (unchanged core)
// ================================================================

function mkM(){
  return {
    ef: 2.5, interval: 0, reps: 0,
    nextReview: null, lastReview: null,
    totalAttempts: 0, totalWrong: 0,
    phase: 'new', learningStepIdx: 0, reLearningStepIdx: 0,
    prevInterval: 0, consecutiveCorrect: 0
  };
}

function updateMemState(q, ok){
  var mem = geM(q.id) || mkM();
  var now = new Date(), nowS = now.toISOString();
  mem.lastReview = nowS;
  mem.totalAttempts = (mem.totalAttempts || 0) + 1;
  if (!ok) mem.totalWrong = (mem.totalWrong || 0) + 1;

  var score;
  if (!ok) {
    var type = q.type || 1, ua = A[q.id].a || '', ca = q.correctAnswer || '';
    if (type === 1 || ca.length <= 2) score = 0;
    else {
      var uSet = ua.split(','), cSet = ca.split(',');
      var match = cSet.filter(function(x){ return uSet.indexOf(x) >= 0; }).length;
      score = match > 0 ? 2 : 1;
    }
  } else {
    var prev = geM(q.id);
    score = (prev && prev.reps >= 3) ? 5 : 4;
  }

  if (score >= 3) mem.consecutiveCorrect = (mem.consecutiveCorrect || 0) + 1;
  else mem.consecutiveCorrect = 0;

  if (score >= 3) {
    if (mem.phase === 'new' || mem.phase === 'learning') {
      var steps = [0.0208, 0.0833, 1];
      if (mem.learningStepIdx < steps.length - 1) {
        mem.learningStepIdx++; mem.phase = 'learning';
        mem.interval = steps[mem.learningStepIdx];
      } else { mem.phase = 'exponential'; mem.reps = 0; mem.interval = 1; }
    } else if (mem.phase === 'exponential') {
      mem.reps += 1;
      mem.interval = mem.reps === 1 ? 6 : Math.round(mem.interval * mem.ef);
    } else if (mem.phase === 'relearning') {
      var rsteps = [0.0208, 0.0833, 1];
      if (mem.reLearningStepIdx < rsteps.length - 1) {
        mem.reLearningStepIdx++; mem.interval = rsteps[mem.reLearningStepIdx];
      } else {
        mem.phase = 'exponential'; mem.reps = 0;
        mem.interval = Math.max(1, Math.round((mem.prevInterval || 1) * 0.1));
      }
    }
    mem.ef = mem.ef + (0.1 - (5 - score) * (0.08 + (5 - score) * 0.02));
    if (mem.ef < 1.3) mem.ef = 1.3;

    if (mem.nextReview) {
      var due = new Date(mem.nextReview).getTime();
      if (now.getTime() > due) {
        var overdue = Math.floor((now.getTime() - due) / 86400000);
        var div = score === 3 ? 4 : score === 4 ? 2 : 1;
        mem.interval += Math.floor(overdue / div);
      }
    }
  } else {
    if (mem.phase === 'exponential') mem.prevInterval = mem.interval;
    mem.phase = 'relearning'; mem.reLearningStepIdx = 0;
    mem.interval = 0.0208; mem.reps = 0;
    mem.ef = Math.max(mem.ef - 0.2, 1.3);
  }

  mem.nextReview = new Date(now.getTime() + mem.interval * 86400000).toISOString().substring(0, 10);
  seM(q.id, mem);
  tryRemoveError(q, mem);
}

// ================================================================
// CONSOLIDATION-BASED ERROR MANAGEMENT
// ================================================================

function tryRemoveError(q, mem){
  var d = GS();
  var inW = d.w.some(function(w){ return String(w.id) === String(q.id); });
  if (!inW) return;
  if (mem.phase !== 'exponential') return;
  if (mem.ef < 2.3) return;
  if ((mem.consecutiveCorrect || 0) < 2) return;
  if (!mem.lastReview) return;
  if (daysBetween(mem.lastReview, new Date().toISOString()) < 3) return;
  d.w = d.w.filter(function(w){ return String(w.id) !== String(q.id); });
  mem.spotCheck = new Date(Date.now() + 30 * 86400000).toISOString().substring(0, 10);
  seM(q.id, mem);
  SS(d);
}

// Record wrong: always dedupe
function rW(q){
  var d = GS();
  if (!d.w.some(function(w){ return String(w.id) === String(q.id); })) {
    d.w.push({ id: q.id, time: new Date().toISOString(), s: q.lawName, c: (q.content || '').substring(0, 80), a: q.correctAnswer });
  }
  d.done[q.id] = { law: q.lawName, ok: false, time: new Date().toISOString() };
  SS(d);
}

// ================================================================
// OFFLINE TOPIC EXTRACTION (Python preprocessing)
// ================================================================

/*
import json, gzip, re

JUNK_STARTS = ['正确答案', '错误说法', '正确说法', '本题主要', 'A选项', 'B选项', 'C选项', 'D选项']
STRIP_PREFIXES = ['本题主要', '本题综合', '本题', '主要']

def clean_topic(t):
    for p in STRIP_PREFIXES:
        if t.startswith(p): t = t[len(p):]
    t = t.strip()
    if len(t) < 2: return None
    return t[:16]

def extract_topic(q):
    r = q.get('questionResolution', '')
    law = q.get('lawName', '')

    # Layer 1: 本题考查/考点/涉及/体现
    m = re.search(r'本题(?:考查|考[点了]|考点|涉及|体现)(.+?)[。，、\n]', r)
    if m:
        t = clean_topic(m.group(1).strip())
        if t and not any(t.startswith(s) for s in JUNK_STARTS):
            return law + '.' + t

    # Layer 2: Alternate prefix
    m = re.search(r'^[（(]?(.+?)(?:考查|考点|涉及)(.+?)[。，、\n]', r)
    if m:
        t = clean_topic((m.group(1) + m.group(2)).strip())
        if t and not any(t.startswith(s) for s in JUNK_STARTS):
            return law + '.' + t

    # Layer 3: 本题XXX (fallback)
    m = re.search(r'本题(.+?)[。，、\n]', r)
    if m:
        t = clean_topic(m.group(1).strip())
        if t and not any(t.startswith(s) for s in JUNK_STARTS):
            return law + '.' + t

    # Layer 4: First sentence
    m = re.search(r'^(.+?)[。，\n]', r)
    if m:
        t = clean_topic(m.group(1).strip())
        if t and not any(t.startswith(s) for s in JUNK_STARTS):
            return law + '.' + t

    return law + '.other'

# Process
with gzip.open('all_questions.json.gz') as f:
    data = json.load(f)
for q in data:
    q['topic'] = extract_topic(q)
with gzip.open('all_questions.json.gz', 'wt') as f:
    json.dump(data, f, ensure_ascii=False, separators=(',', ':'))
*/
